#!/usr/bin/env bash
set -euo pipefail
exec > >(tee -i logs/run_all.out) 2> >(tee -i logs/run_all.err >&2)
conda activate tp53env

echo "=== FETCH ==="
python scripts/fetch_tp53_orthologs.py
echo "Sequences: $(grep -c '^>' data/all/tp53_50_species.fasta)"

echo "=== BLAST DB ==="
bash scripts/build_blast_db.sh

echo "=== BLAST RUN ==="
bash scripts/run_blast.sh

echo "=== PARSE BLAST ==="
python scripts/parse_blast.py

echo "=== MSA ==="
bash scripts/run_msa.sh

echo "=== CONSERVATION ==="
python scripts/conservation.py

echo "=== PHYLOGENY ==="
bash scripts/phylo.sh
python scripts/plot_tree.py

echo "=== ML (5-fold) ==="
python scripts/ml_classification_cv.py

echo "=== COMPARE BIO vs ML ==="
python scripts/compare_bio_vs_ml.py

echo "=== DONE ==="
