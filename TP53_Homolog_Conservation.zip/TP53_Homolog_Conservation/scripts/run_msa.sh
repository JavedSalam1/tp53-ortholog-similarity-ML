#!/usr/bin/env bash
set -euo pipefail
mkdir -p results logs
muscle -align data/all/tp53_50_species.fasta -output results/tp53_50_aln.fasta 1>logs/muscle.log 2>&1
echo "MSA: results/tp53_50_aln.fasta"
