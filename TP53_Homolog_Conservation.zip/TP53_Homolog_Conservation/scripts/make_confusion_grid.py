#!/usr/bin/env python3
import sys
from pathlib import Path
import matplotlib.pyplot as plt
from PIL import Image

# Expected inputs from your existing pipeline
paths = {
    "RandomForest": "figures/ml_randomforest_confusion.png",
    "SVM (RBF)":    "figures/ml_svm_rbf_confusion.png",
    "Logistic Regression": "figures/ml_logreg_confusion.png",
}

# Check files exist
missing = [p for p in paths.values() if not Path(p).exists()]
if missing:
    sys.exit("Missing input image(s):\n  " + "\n  ".join(missing) +
             "\nRun: python scripts/ml_classification_cv.py to regenerate them.")

# Load images
imgs = {k: Image.open(v) for k, v in paths.items()}

# Build 1x3 grid
plt.figure(figsize=(12, 4))
for i, (title, img) in enumerate(imgs.items(), start=1):
    ax = plt.subplot(1, 3, i)
    ax.imshow(img)
    ax.axis('off')
    ax.set_title(title, fontsize=11)

plt.suptitle("Confusion matrices (5-fold CV aggregate)", fontsize=12, y=0.99)
plt.tight_layout(rect=[0, 0, 1, 0.95])

Path("figures").mkdir(exist_ok=True)
out_png = Path("figures/ml_confusion_triptych.png")
out_pdf = Path("figures/ml_confusion_triptych.pdf")
plt.savefig(out_png, dpi=300)
plt.savefig(out_pdf)
print(f"Saved {out_png}\nSaved {out_pdf}")
