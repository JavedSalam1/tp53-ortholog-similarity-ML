#!/usr/bin/env python3
from Bio import Phylo
import matplotlib.pyplot as plt
import pandas as pd
import argparse

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--nwk", default="results/tp53_tree.nwk")
    ap.add_argument("--meta", default="tables/species_metadata.csv")
    ap.add_argument("--out", default="figures/tp53_tree_clean.png")
    args = ap.parse_args()

    # Load tree
    tree = Phylo.read(args.nwk, "newick")

    # Load metadata (species + labels)
    meta = pd.read_csv(args.meta)
    label_map = {row["species"]: row["label"] for _, row in meta.iterrows()}

    # Clean labels (keep only species name)
    for clade in tree.get_terminals():
        if clade.name:
            clade.name = clade.name.split("|")[0]

    # Define label coloring (string-based)
    def label_color(name):
        if not name:
            return "black"
        sp = name.split("|")[0]
        if sp in label_map:
            return "blue" if label_map[sp] == "close" else "red"
        return "black"

    # Plot tree with smaller fonts
    plt.figure(figsize=(20, 40))
    Phylo.draw(
        tree,
        label_colors=label_color,
        do_show=False,
    )

    # Make species names + values smaller
    for ax in plt.gcf().axes:
        for label in ax.get_xticklabels() + ax.get_yticklabels():
            label.set_fontsize(3)   # axis ticks
        for text in ax.texts:       # tree labels (species + values)
            text.set_fontsize(4)

    # Save
    plt.savefig(args.out, dpi=300, bbox_inches="tight")
    print(f"Saved: {args.out}")

if __name__ == "__main__":
    main()
