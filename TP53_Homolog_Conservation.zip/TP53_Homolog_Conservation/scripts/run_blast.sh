#!/usr/bin/env bash
set -euo pipefail
mkdir -p results logs
blastp \
  -query data/human/human_tp53.fasta \
  -db data/blastdb/tp53_db \
  -evalue 1e-5 \
  -outfmt "6 qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore qlen slen" \
  -max_target_seqs 10000 \
  -num_threads 4 \
  -out results/blastp_tp53_vs_orthologs.tsv 1>logs/blastp.log 2>&1
echo "BLAST output: results/blastp_tp53_vs_orthologs.tsv"
