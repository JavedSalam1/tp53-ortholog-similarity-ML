#!/usr/bin/env python3
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

labels_csv = Path("tables/bio_vs_ml_labels.csv")
comp_json  = Path("tables/bio_ml_comparison.json")

# Load labels and compute agree/disagree on species with both labels present
df = pd.read_csv(labels_csv)
common = df.dropna(subset=["ml_label"]).copy()
common["agree"] = (common["bio_cluster"].astype(int) == common["ml_label"].astype(int))
agree = int(common["agree"].sum())
disagree = int((~common["agree"]).sum())
n_common = int(len(common))

# Get ARI from JSON if available; otherwise compute it
try:
    data = json.loads(comp_json.read_text())
    ari = float(data.get("adjusted_rand_index", np.nan))
except Exception:
    from sklearn.metrics import adjusted_rand_score
    ari = float(adjusted_rand_score(common["bio_cluster"].astype(int),
                                    common["ml_label"].astype(int)))

# Plot
plt.figure(figsize=(5,4))
bars = plt.bar(["Agree","Disagree"], [agree, disagree])
# Put exact counts above bars
for b in bars:
    h = b.get_height()
    plt.text(b.get_x() + b.get_width()/2, h + max(1, 0.02*n_common), str(int(h)),
             ha="center", va="bottom", fontsize=10)
plt.title(f"BIO vs ML Agreement (ARI={ari:.3f}; n={n_common})")
plt.ylabel("Species count")
plt.ylim(0, max(agree,disagree)*1.25 if n_common>0 else 1)

plt.tight_layout()
Path("figures").mkdir(exist_ok=True)
for ext in ("png","pdf"):
    out = Path(f"figures/bio_vs_ml_agreement_pub.{ext}")
    plt.savefig(out, dpi=300 if ext=="png" else None)
    print(f"Saved {out}")
