#!/usr/bin/env python3
import pandas as pd, argparse

def parse_species(sseqid):
    return sseqid.split("|")[0].replace("_"," ")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--blast_tsv", default="results/blastp_tp53_vs_orthologs.tsv")
    ap.add_argument("--species_meta", default="tables/species_metadata.csv")
    ap.add_argument("--out_csv", default="tables/tp53_blast_features.csv")
    args = ap.parse_args()

    cols = ["qseqid","sseqid","pident","length","mismatch","gapopen","qstart","qend","sstart","send","evalue","bitscore","qlen","slen"]
    df = pd.read_csv(args.blast_tsv, sep="\t", header=None, names=cols)

    df["qcov"] = df["length"] / df["qlen"]
    df["scov"] = df["length"] / df["slen"]
    df["coverage"] = df[["qcov","scov"]].min(axis=1)
    df["species"] = df["sseqid"].map(parse_species)

    df_best = df.sort_values(["species","bitscore"], ascending=[True,False]).drop_duplicates("species")

    meta = pd.read_csv(args.species_meta)
    feat = df_best.merge(meta[["species","label","taxon_id"]], on="species", how="left")

    keep = ["species","taxon_id","pident","length","evalue","bitscore","coverage","qlen","slen","label"]
    feat = feat[keep].sort_values("pident", ascending=False)
    feat.to_csv(args.out_csv, index=False)
    print(f"Saved features: {args.out_csv} (n={len(feat)})")

if __name__ == "__main__":
    main()
