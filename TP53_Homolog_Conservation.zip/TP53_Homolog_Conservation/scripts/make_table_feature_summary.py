#!/usr/bin/env python3
import pandas as pd, numpy as np
from pathlib import Path

inp = Path("tables/tp53_blast_features.csv")
df = pd.read_csv(inp).dropna(subset=["label"])

# Ensure types
num_cols = ["pident","length","bitscore","coverage","qlen","slen"]
if "log_evalue" in df.columns:
    num_cols.append("log_evalue")

# Cohen's d helper
def cohend(a, b):
    a, b = np.asarray(a), np.asarray(b)
    na, nb = len(a), len(b)
    sa, sb = a.std(ddof=1), b.std(ddof=1)
    s = np.sqrt(((na-1)*sa**2 + (nb-1)*sb**2) / (na+nb-2)) if (na>1 and nb>1) else np.nan
    return (a.mean() - b.mean()) / s if s>0 else np.nan

# Summaries by label
summ = (df
        .groupby("label")[num_cols]
        .agg(["mean","std","count"])
        .rename_axis(index="label"))
# Flatten columns
summ.columns = [f"{c}_{stat}" for c,stat in summ.columns]
summ = summ.reset_index()

# Compute effect sizes Close vs Distant
close = df[df.label=="close"]
dist  = df[df.label=="distant"]
effects = {col: cohend(close[col], dist[col]) for col in num_cols}

# Build LaTeX rows
def fmt_ms(m, s):
    return f"{m:.3f} ± {s:.3f}"

rows = []
for col in ["pident","bitscore","coverage","length","qlen","slen","log_evalue" if "log_evalue" in num_cols else None]:
    if col is None: continue
    m_close = summ.loc[summ.label=="close", f"{col}_mean"].item() if "close" in summ.label.values else np.nan
    s_close = summ.loc[summ.label=="close", f"{col}_std"].item()  if "close" in summ.label.values else np.nan
    m_dist  = summ.loc[summ.label=="distant", f"{col}_mean"].item() if "distant" in summ.label.values else np.nan
    s_dist  = summ.loc[summ.label=="distant", f"{col}_std"].item()  if "distant" in summ.label.values else np.nan
    d = effects[col]
    rows.append((col, fmt_ms(m_close, s_close), fmt_ms(m_dist, s_dist), d))

# Write LaTeX
out = Path("tables/table_feature_summary.tex")
with out.open("w") as f:
    f.write(r"% Requires \usepackage{booktabs} \usepackage{siunitx}"+"\n")
    f.write(r"\begin{table}[htbp]"+"\n")
    f.write(r"\centering"+"\n")
    f.write(r"\caption{BLAST-derived feature summary by ML label (mean $\pm$ SD). Cohen's $d$ quantifies effect size (Close vs Distant).}"+"\n")
    f.write(r"\label{tab:feat-summary}"+"\n")
    f.write(r"\renewcommand{\arraystretch}{1.2}"+"\n")
    f.write(r"\scriptsize"+"\n")
    f.write(r"\begin{tabular}{l l l r}"+"\n")
    f.write(r"\toprule"+"\n")
    f.write(r"\textbf{Feature} & \textbf{Close} & \textbf{Distant} & \textbf{Cohen's $d$} \\"+"\n")
    f.write(r"\midrule"+"\n")
    for col, c_ms, d_ms, d in rows:
        label = {"pident":"Percent identity",
                 "bitscore":"Bitscore",
                 "coverage":"Coverage (min of q/s)",
                 "length":"Alignment length",
                 "qlen":"Query length",
                 "slen":"Subject length",
                 "log_evalue":"$\log_{10}$(E-value)"}[col]
        f.write(f"{label} & {c_ms} & {d_ms} & {d:.2f} \\\\\n")
    f.write(r"\bottomrule"+"\n")
    f.write(r"\end{tabular}"+"\n")
    f.write(r"\end{table}"+"\n")
print(f"Wrote {out}")
