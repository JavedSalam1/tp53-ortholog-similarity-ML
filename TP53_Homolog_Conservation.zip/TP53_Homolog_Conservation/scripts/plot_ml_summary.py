#!/usr/bin/env python3
import json, numpy as np, matplotlib.pyplot as plt
from pathlib import Path

# Try to load your CV summary; if not found, use hard-coded means/stds.
fallback = {
  "RandomForest": {"accuracy":{"mean":0.8577777777777778,"std":0.05293835222031818},
                   "precision":{"mean":0.86,"std":0.12942179105544785},
                   "recall":{"mean":0.8,"std":0.11180339887498948},
                   "f1":{"mean":0.8206349206349206,"std":0.065770143425326},
                   "roc_auc":{"mean":0.8483333333333334,"std":0.11002682753664117}},
  "SVM_RBF":     {"accuracy":{"mean":0.7755555555555557,"std":0.08292492514242354},
                   "precision":{"mean":0.7476190476190476,"std":0.15914133252810492},
                   "recall":{"mean":0.75,"std":0.1767766952966369},
                   "f1":{"mean":0.7311688311688311,"std":0.10260459452024481},
                   "roc_auc":{"mean":0.8574999999999999,"std":0.061548309842305526}},
  "LogReg":      {"accuracy":{"mean":0.6733333333333332,"std":0.04346134936801765},
                   "precision":{"mean":0.7666666666666666,"std":0.22360679774997896},
                   "recall":{"mean":0.35,"std":0.13693063937629152},
                   "f1":{"mean":0.4552380952380952,"std":0.10950310363279853},
                   "roc_auc":{"mean":0.6508333333333335,"std":0.1526501992574308}}
}

def load_metrics(path="tables/ml_cv_summary.json"):
    p = Path(path)
    if p.exists():
        return json.loads(p.read_text())
    return fallback

data = load_metrics()

models = ["RandomForest","SVM_RBF","LogReg"]
metrics = ["accuracy","precision","recall","f1","roc_auc"]

means = {m:[data[k][m]["mean"] for k in models] for m in metrics}
stds  = {m:[data[k][m]["std"]  for k in models] for m in metrics}

x = np.arange(len(models))
w = 0.16

plt.figure(figsize=(11,6))
for i, m in enumerate(metrics):
    plt.bar(x + (i-2)*w, means[m], yerr=stds[m], width=w, capsize=3, label=m.capitalize())

plt.xticks(x, ["RF","SVM","LogReg"])
plt.ylabel("Score")
plt.ylim(0,1.05)
plt.title("Cross-validated performance (mean ± SD, 5 folds)")
plt.legend(ncol=3, fontsize=9, frameon=False)
plt.grid(axis='y', linestyle=':', linewidth=0.6)
Path("figures").mkdir(exist_ok=True)
plt.tight_layout()
for ext in ("png","pdf","svg"):
    out = Path(f"figures/ml_model_performance_summary.{ext}")
    plt.savefig(out, dpi=300 if ext=="png" else None)
    print(f"Saved {out}")
