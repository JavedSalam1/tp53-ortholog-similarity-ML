#!/usr/bin/env python3
import argparse, numpy as np, pandas as pd, matplotlib.pyplot as plt
from Bio import AlignIO

def column_conservation(aln):
    cons=[]
    for i in range(aln.get_alignment_length()):
        col=[rec.seq[i] for rec in aln if rec.seq[i] != "-"]
        if not col: cons.append(0.0); continue
        _, cnt = np.unique(col, return_counts=True)
        cons.append(cnt.max()/cnt.sum())
    return np.array(cons)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--aln", default="results/tp53_50_aln.fasta")
    ap.add_argument("--out_csv", default="tables/tp53_conservation.csv")
    ap.add_argument("--out_fig", default="figures/conservation_heatmap.png")
    args = ap.parse_args()

    aln = AlignIO.read(args.aln, "fasta")
    cons = column_conservation(aln)
    pd.DataFrame({"position": np.arange(1,len(cons)+1), "conservation": cons}).to_csv(args.out_csv, index=False)

    plt.figure(figsize=(14,2))
    plt.imshow(cons[np.newaxis,:], aspect="auto")
    plt.yticks([]); plt.xlabel("Alignment position")
    plt.title("TP53 per-position conservation"); plt.colorbar(label="Mode fraction")
    plt.tight_layout(); plt.savefig(args.out_fig, dpi=300)
    print(f"Saved: {args.out_csv}, {args.out_fig}")

if __name__ == "__main__":
    main()
