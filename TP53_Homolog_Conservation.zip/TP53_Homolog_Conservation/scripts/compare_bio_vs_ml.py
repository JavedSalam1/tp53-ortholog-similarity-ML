#!/usr/bin/env python3
import json
from pathlib import Path

import numpy as np
import pandas as pd
from Bio import AlignIO
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import adjusted_rand_score
import matplotlib.pyplot as plt


def p_distance(seq_a: str, seq_b: str) -> float:
    """
    Proportion of differences over non-gap overlapping positions.
    """
    pairs = [(x, y) for x, y in zip(seq_a, seq_b) if (x != "-") and (y != "-")]
    if not pairs:
        return 1.0
    diff = sum(x != y for x, y in pairs)
    return diff / len(pairs)


def header_to_species(header: str) -> str:
    # headers were written like: Species_Name|PROT|GENE|taxon:XXXX
    return header.split("|")[0].replace("_", " ")


def main():
    aln_path = Path("results/tp53_50_aln.fasta")
    feat_path = Path("tables/tp53_blast_features.csv")
    tables_dir = Path("tables")
    figs_dir = Path("figures")
    tables_dir.mkdir(exist_ok=True)
    figs_dir.mkdir(exist_ok=True)

    if not aln_path.exists():
        raise FileNotFoundError(f"Missing alignment: {aln_path} (run MUSCLE step first)")
    if not feat_path.exists():
        raise FileNotFoundError(f"Missing features: {feat_path} (run parse_blast.py first)")

    # Read alignment
    aln = AlignIO.read(str(aln_path), "fasta")
    names = [rec.id for rec in aln]
    seqs = [str(rec.seq) for rec in aln]

    # Pairwise p-distance matrix
    n = len(seqs)
    D = np.zeros((n, n), dtype=float)
    for i in range(n):
        for j in range(i + 1, n):
            d = p_distance(seqs[i], seqs[j])
            D[i, j] = D[j, i] = d

    # Cluster (sklearn >=1.4: use metric="precomputed")
    clus = AgglomerativeClustering(n_clusters=2, metric="precomputed", linkage="average")
    labels_bio = clus.fit_predict(D)

    # ML labels map (close=1, distant=0)
    feat = pd.read_csv(feat_path)
    ml_map = {row["species"]: (1 if row["label"] == "close" else 0) for _, row in feat.iterrows()}

    rows = []
    for idx, h in enumerate(names):
        sp = header_to_species(h)
        ml = ml_map.get(sp, None)  # human may be missing here; that's OK
        rows.append({
            "species": sp,
            "bio_cluster": int(labels_bio[idx]),
            "ml_label": (int(ml) if ml is not None else np.nan)
        })

    out_labels_csv = tables_dir / "bio_vs_ml_labels.csv"
    pd.DataFrame(rows).to_csv(out_labels_csv, index=False)

    # ARI over common species
    common = pd.DataFrame(rows).dropna(subset=["ml_label"]).copy()
    ari = adjusted_rand_score(common["bio_cluster"], common["ml_label"])

    out_json = tables_dir / "bio_ml_comparison.json"
    out_json.write_text(json.dumps({
        "n_common": int(len(common)),
        "adjusted_rand_index": float(ari)
    }, indent=2))

    # Agreement plot
    agree_counts = (common["bio_cluster"] == common["ml_label"]).value_counts()
    agree = int(agree_counts.get(True, 0))
    disagree = int(agree_counts.get(False, 0))

    plt.figure(figsize=(4, 3))
    plt.bar(["Agree", "Disagree"], [agree, disagree])
    plt.title(f"BIO vs ML (ARI={ari:.3f})")
    plt.ylabel("Species count")
    plt.tight_layout()
    out_png = figs_dir / "bio_vs_ml_agreement.png"
    plt.savefig(out_png, dpi=300)

    print(f"Saved:\n - {out_labels_csv}\n - {out_json}\n - {out_png}")


if __name__ == "__main__":
    main()
