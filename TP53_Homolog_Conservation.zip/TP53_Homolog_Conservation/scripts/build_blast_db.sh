#!/usr/bin/env bash
set -euo pipefail
mkdir -p data/blastdb results logs
if [ ! -f data/orthologs/tp53_orthologs_49.fasta ]; then
  cat data/orthologs/*.fasta > data/orthologs/tp53_orthologs_49.fasta
fi
makeblastdb -in data/orthologs/tp53_orthologs_49.fasta -dbtype prot -out data/blastdb/tp53_db 1>logs/makeblastdb.log 2>&1
echo "BLAST DB ready: data/blastdb/tp53_db"
