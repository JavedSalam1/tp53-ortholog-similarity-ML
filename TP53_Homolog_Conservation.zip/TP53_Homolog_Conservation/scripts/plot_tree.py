#!/usr/bin/env python3
from Bio import Phylo
import matplotlib.pyplot as plt
import argparse
ap = argparse.ArgumentParser()
ap.add_argument("--nwk", default="results/tp53_tree.nwk")
ap.add_argument("--out", default="figures/tp53_tree.png")
args = ap.parse_args()
tree = Phylo.read(args.nwk, "newick")
plt.figure(figsize=(12,20))
Phylo.draw(tree, do_show=False)
plt.tight_layout()
plt.savefig(args.out, dpi=300)
print(f"Saved: {args.out}")
