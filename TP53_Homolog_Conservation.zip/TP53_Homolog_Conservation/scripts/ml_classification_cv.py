#!/usr/bin/env python3
import json, numpy as np, pandas as pd
from pathlib import Path
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, roc_auc_score, confusion_matrix
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
import matplotlib.pyplot as plt

RNG=42

def eval_model(model_name, pipe, X, y, out_prefix):
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=RNG)
    metrics = []; cms = np.zeros((2,2), dtype=int)
    for fold, (tr, te) in enumerate(skf.split(X,y), 1):
        pipe.fit(X.iloc[tr], y[tr])
        y_pred = pipe.predict(X.iloc[te])
        if hasattr(pipe, "predict_proba"):
            y_score = pipe.predict_proba(X.iloc[te])[:,1]
        elif hasattr(pipe, "decision_function"):
            dfun = pipe.decision_function(X.iloc[te])
            y_score = (dfun - dfun.min()) / max(1e-9, (dfun.max()-dfun.min()))
        else:
            y_score = np.zeros_like(y_pred, dtype=float)
        acc = accuracy_score(y[te], y_pred)
        prec, rec, f1, _ = precision_recall_fscore_support(y[te], y_pred, average="binary", zero_division=0)
        try: auc = roc_auc_score(y[te], y_score)
        except: auc = float("nan")
        metrics.append({"fold":fold,"accuracy":acc,"precision":prec,"recall":rec,"f1":f1,"roc_auc":auc})
        cms += confusion_matrix(y[te], y_pred, labels=[0,1])
    m = pd.DataFrame(metrics)
    summary = {k:{"mean":float(m[k].mean()),"std":float(m[k].std())} for k in ["accuracy","precision","recall","f1","roc_auc"]}
    Path("tables").mkdir(exist_ok=True); Path("figures").mkdir(exist_ok=True)
    Path(f"tables/{out_prefix}_metrics.json").write_text(json.dumps({"model":model_name,"cv":metrics,"summary":summary}, indent=2))
    plt.figure(figsize=(4,4))
    plt.imshow(cms, interpolation="nearest")
    plt.xticks([0,1],["distant","close"]); plt.yticks([0,1],["distant","close"])
    for (i,j),v in np.ndenumerate(cms): plt.text(j,i,str(v),ha="center",va="center")
    plt.xlabel("Predicted"); plt.ylabel("True"); plt.title(f"{model_name} 5-fold Confusion")
    plt.tight_layout(); plt.savefig(f"figures/{out_prefix}_confusion.png", dpi=300); plt.close()
    return summary

def main():
    df = pd.read_csv("tables/tp53_blast_features.csv").dropna(subset=["label"])
    y = (df["label"]=="close").astype(int).values
    X = df[["pident","length","bitscore","coverage","qlen","slen","evalue"]].copy()
    X["log_evalue"] = np.log10(np.maximum(X["evalue"], 1e-300)); X = X.drop(columns=["evalue"])
    models = [
        ("RandomForest", Pipeline([("scaler", StandardScaler()), ("rf", RandomForestClassifier(n_estimators=600, random_state=RNG))])),
        ("SVM_RBF", Pipeline([("scaler", StandardScaler()), ("svm", SVC(C=3.0, gamma="scale", kernel="rbf", probability=True, random_state=RNG))])),
        ("LogReg", Pipeline([("scaler", StandardScaler()), ("lr", LogisticRegression(max_iter=500, random_state=RNG))]))
    ]
    out = {name: eval_model(name, pipe, X, y, out_prefix=f"ml_{name.lower()}") for name,pipe in models}
    Path("tables/ml_cv_summary.json").write_text(json.dumps(out, indent=2))
    print("Saved metrics to tables/*.json and plots to figures/*.png")

if __name__ == "__main__":
    main()
