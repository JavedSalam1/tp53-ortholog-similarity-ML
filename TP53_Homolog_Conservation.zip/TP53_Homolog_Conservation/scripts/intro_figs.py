import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch, Circle
from pathlib import Path

plt.rcParams.update({"font.size": 13, "axes.linewidth": 1.6})

# ---------- Figure 1: TP53 domain schematic (labels outside) ----------
L = 393
def res_to_x(pos, x0, w): return x0 + (pos / L) * w

fig1, ax1 = plt.subplots(figsize=(7.0, 3.0))
ax1.set_axis_off()
x0, w = 0.08, 0.84
y_bar = 0.60

# Base bar + endpoints only
ax1.add_patch(Rectangle((x0, y_bar), w, 0.05, linewidth=2.0, fill=False, transform=ax1.transAxes))
for t in [1, 393]:
    xt = res_to_x(t, x0, w)
    ax1.plot([xt, xt], [y_bar-0.02, y_bar], lw=1.6, transform=ax1.transAxes, color="black")
    ax1.text(xt, y_bar-0.05, f"{t}", ha="center", va="top", fontsize=12, transform=ax1.transAxes)

domains = [("TAD1", 1, 42), ("TAD2", 43, 62), ("PRR", 63, 94),
           ("DBD", 92, 292), ("OD", 325, 356), ("CTD", 363, 393)]
for name, start, end in domains:
    xL = res_to_x(start, x0, w); xR = res_to_x(end, x0, w)
    ax1.add_patch(Rectangle((xL, y_bar), xR-xL, 0.05, linewidth=1.6, fill=False, transform=ax1.transAxes))
    cx = (xL + xR) / 2
    ax1.plot([cx, cx], [y_bar, 0.43], lw=1.2, transform=ax1.transAxes, color="black")
    ax1.text(cx, 0.40, name, ha="center", va="top", fontsize=13, fontweight="bold", transform=ax1.transAxes)

ax1.text(0.5, 0.93, "TP53 domain architecture (393 aa)", ha="center", va="top",
         fontsize=16, fontweight="bold", transform=ax1.transAxes)

Path("figures").mkdir(exist_ok=True)
fig1.savefig("figures/intro_tp53_domain_v5.png", dpi=600, bbox_inches="tight")
fig1.savefig("figures/intro_tp53_domain_v5.pdf", bbox_inches="tight")
plt.close(fig1)

# ---------- Figure 2: Minimal pipeline swimlane (numbered steps) ----------
fig2, ax2 = plt.subplots(figsize=(6.2, 6.8))
ax2.set_axis_off()
steps = [
    ("1", "Sequences", "50 TP53 orthologs\n(+ human)"),
    ("2", "MSA", "MUSCLE v5"),
    ("3", "Conservation", "per-position (0–1)"),
    ("4", "Phylogeny", "FastTree (WAG)"),
    ("5", "BLAST features", "identity, bitscore,\ncoverage, length"),
    ("6", "ML classification", "RF / SVM-RBF / LogReg\n5-fold CV; compare to BIO (ARI)"),
]
y0, dy = 0.90, 0.14
for i, (num, title, sub) in enumerate(steps):
    y = y0 - i*dy
    circ = Circle((0.12, y), 0.035, fill=False, lw=2.0, transform=ax2.transAxes)
    ax2.add_patch(circ)
    ax2.text(0.12, y, num, ha="center", va="center", fontsize=14, fontweight="bold", transform=ax2.transAxes)
    ax2.text(0.18, y+0.025, title, ha="left", va="center", fontsize=14, fontweight="bold", transform=ax2.transAxes)
    ax2.text(0.18, y-0.020, sub, ha="left", va="center", fontsize=12, transform=ax2.transAxes)
    if i < len(steps)-1:
        ax2.add_patch(FancyArrowPatch((0.12, y-0.045), (0.12, y-dy+0.045),
                                      arrowstyle="-|>", mutation_scale=16, lw=1.8, transform=ax2.transAxes))
ax2.text(0.5, 0.97, "Project overview (bioinformatics → machine learning)", ha="center", va="top",
         fontsize=16, fontweight="bold", transform=ax2.transAxes)

fig2.savefig("figures/intro_pipeline_swimlane_v2.png", dpi=600, bbox_inches="tight")
fig2.savefig("figures/intro_pipeline_swimlane_v2.pdf", bbox_inches="tight")
plt.close(fig2)

print("Saved figures to figures/: intro_tp53_domain_v5.(png|pdf), intro_pipeline_swimlane_v2.(png|pdf)")
