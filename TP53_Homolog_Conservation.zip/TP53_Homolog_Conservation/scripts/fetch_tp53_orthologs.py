#!/usr/bin/env python3
import os, sys, json, time, argparse, re, textwrap, random
from pathlib import Path
import requests
import pandas as pd
from tqdm import tqdm

ENSEMBL = "https://rest.ensembl.org"
UNIPROT_FASTA_HUMAN = "https://rest.uniprot.org/uniprotkb/P04637.fasta"
UNIPROT_SEARCH = "https://rest.uniprot.org/uniprotkb/search"
CACHE_DIR = Path("data/cache")

def ensure_dirs():
    for p in ["data/human","data/orthologs","data/all","tables","data/cache"]:
        Path(p).mkdir(parents=True, exist_ok=True)

def sanitize(s): 
    return re.sub(r'[^A-Za-z0-9_|=;:/\\.\-\\s]', '_', s)

def http_get(url, params=None, expect="json", retries=6, base_sleep=1.0):
    headers = {
        "User-Agent": "tp53-pipeline/1.1",
        "Accept": "application/json" if expect in ("json","text") else "*/*"
    }
    last_err = None
    for i in range(retries):
        try:
            r = requests.get(url, params=params, headers=headers, timeout=45)
            if r.status_code == 200:
                if expect == "json": return r.json()
                elif expect == "text": return r.text
                else: return r.content
            elif r.status_code in (429, 503):
                ra = r.headers.get("Retry-After")
                sleep = float(ra) if (ra and ra.isdigit()) else (base_sleep * (2 ** i))
                time.sleep(sleep); continue
            else:
                last_err = f"HTTP {r.status_code}: {r.text[:200]}"
        except requests.RequestException as e:
            last_err = str(e)
        time.sleep(base_sleep * (2 ** i))
    raise RuntimeError(f"GET failed: {url}\nDetails: {last_err}")

def cache_json(name, func):
    p = CACHE_DIR / f"{name}.json"
    if p.exists(): return json.loads(p.read_text())
    d = func(); p.write_text(json.dumps(d)); return d

def cache_text(name, func):
    p = CACHE_DIR / f"{name}.txt"
    if p.exists(): return p.read_text()
    t = func(); p.write_text(t); return t

def ensembl_homologies_by_id(gene_id="ENSG00000141510"):
    url = f"{ENSEMBL}/homology/id/{gene_id}"
    params = {"type":"orthologues","sequence":"protein","aligned":"0"}
    return cache_json(f"homologies_{gene_id}", lambda: http_get(url, params=params, expect="json"))

def ensembl_homologies_by_symbol(species="homo_sapiens", symbol="TP53"):
    url = f"{ENSEMBL}/homology/symbol/{species}/{symbol}"
    params = {"type":"orthologues","sequence":"protein","aligned":"0"}
    return cache_json(f"homologies_{species}_{symbol}", lambda: http_get(url, params=params, expect="json"))

def ensembl_sequence_by_protein_id(protein_id):
    url = f"{ENSEMBL}/sequence/id/{protein_id}"
    params = {"type":"protein"}
    data = cache_json(f"seq_{protein_id}", lambda: http_get(url, params=params, expect="json"))
    return data.get("seq")

def ensembl_taxon_lineage(taxon_id: int):
    url = f"{ENSEMBL}/taxonomy/id/{taxon_id}"
    data = cache_json(f"taxon_{taxon_id}", lambda: http_get(url, expect="json"))
    return [n.get("scientific_name","") for n in data.get("lineage",[])]

def uniprot_search_tp53(max_rows=500):
    params = {
        "query": "gene:TP53 AND reviewed:true",
        "format": "json",
        "fields": "accession,organism_name,organism_id,length,protein_name",
        "size": str(max_rows)
    }
    data = cache_json("uniprot_tp53_search", lambda: http_get(UNIPROT_SEARCH, params=params, expect="json"))
    results = data.get("results", [])
    rows = []
    for r in results:
        acc = r.get("primaryAccession")
        org = r.get("organism", {})
        species = org.get("scientificName") or r.get("organism_name") or ""
        org_id = org.get("taxonId") or r.get("organism_id")
        length = None
        try: length = int(r.get("sequence", {}).get("length") or r.get("length"))
        except: length = None
        rows.append({"accession": acc, "species": species, "taxon_id": org_id, "seq_len": length})
    df = pd.DataFrame(rows).dropna(subset=["accession","species"]).drop_duplicates(subset=["species"])
    return df

def fetch_uniprot_fasta(accession):
    url = f"https://rest.uniprot.org/uniprotkb/{accession}.fasta"
    return cache_text(f"uniprot_fa_{accession}", lambda: http_get(url, expect="text"))

def fetch_human_fasta(out_path: Path):
    txt = cache_text("human_p04637", lambda: http_get(UNIPROT_FASTA_HUMAN, expect="text"))
    out_path.write_text(txt); return out_path

def label_by_policy(species, lineage, policy):
    lin = " > ".join(lineage or [])
    for k in policy.get("close_if_taxon_contains", []):
        if k.lower() in lin.lower(): return "close"
    for k in policy.get("distant_if_taxon_contains", []):
        if k.lower() in lin.lower(): return "distant"
    s = (species or "").lower()
    for k in [x.lower() for x in policy.get("fallback_close_keywords", [])]:
        if k in s: return "close"
    return "distant"

def main():
    ap = argparse.ArgumentParser(description="Fetch TP53 orthologs (Ensembl preferred; UniProt fallback).")
    ap.add_argument("--config", default="config/selection_config.json")
    ap.add_argument("--label_policy", default="config/label_policy.json")
    ap.add_argument("--n_total", type=int, default=50, help="Total species including human.")
    ap.add_argument("--human_out", default="data/human/human_tp53.fasta")
    ap.add_argument("--orthologs_dir", default="data/orthologs")
    ap.add_argument("--all_fasta", default="data/all/tp53_50_species.fasta")
    ap.add_argument("--species_meta", default="tables/species_metadata.csv")
    ap.add_argument("--force_uniprot", action="store_true", help="Use UniProt only and skip Ensembl.")
    args = ap.parse_args()

    ensure_dirs()
    cfg = json.loads(Path(args.config).read_text()) if Path(args.config).exists() else {
        "total_species": args.n_total, "min_mammals": 20, "min_non_mammals": 15,
        "min_protein_length": 200, "max_protein_length": 600, "random_seed": 42
    }
    policy = json.loads(Path(args.label_policy).read_text()) if Path(args.label_policy).exists() else {
        "close_if_taxon_contains": ["Mammalia","Primates"],
        "distant_if_taxon_contains": [],
        "fallback_close_keywords": ["human","homo ","pan ","gorilla","macaca","mouse","mus ","rat","rattus","canis","felis","bos ","sus ","ovis","equus","ursus","delphin","balaen","panthera"]
    }
    random.seed(cfg.get("random_seed", 42))

    print("[1/6] Human TP53 (UniProt P04637)")
    fetch_human_fasta(Path(args.human_out))

    orth_rows = []; used_source = None
    if not args.force_uniprot:
        print("[2/6] Ensembl orthologs by Gene ID ...")
        hom = None
        try:
            hom = ensembl_homologies_by_id("ENSG00000141510")
            used_source = "ensembl_id"
        except Exception as e1:
            print(f"  Ensembl ID failed: {e1}")
            print("[2b/6] Ensembl orthologs by Symbol ...")
            try:
                hom = ensembl_homologies_by_symbol("homo_sapiens","TP53")
                used_source = "ensembl_symbol"
            except Exception as e2:
                print(f"  Ensembl symbol failed: {e2}")
                hom = None
        if hom:
            try:
                for h in hom["data"][0]["homologies"]:
                    t = h.get("target", {})
                    species = (t.get("species","") or "").replace("_"," ")
                    prot_id = t.get("protein_id")
                    gene_id_t = t.get("id")
                    taxon_id = t.get("taxon_id")
                    perc_id = t.get("perc_id")
                    seq = t.get("protein_sequence")
                    if not seq or set(seq)=={"-"}:
                        if prot_id: seq = ensembl_sequence_by_protein_id(prot_id)
                    if not seq: continue
                    if len(seq) < cfg["min_protein_length"] or len(seq) > cfg["max_protein_length"]: continue
                    lineage = ensembl_taxon_lineage(taxon_id) if taxon_id else []
                    orth_rows.append({
                        "species": species, "target_gene_id": gene_id_t, "target_protein_id": prot_id,
                        "taxon_id": taxon_id, "seq": seq, "seq_len": len(seq),
                        "perc_identity": float(perc_id) if perc_id is not None else 0.0,
                        "lineage": lineage
                    })
            except Exception as e:
                print(f"  Ensembl parse failed: {e}")
                orth_rows = []

    if not orth_rows:
        print("[2c/6] UniProt fallback (reviewed TP53 across species)")
        used_source = "uniprot"
        up = uniprot_search_tp53(max_rows=500)
        up = up[(up["seq_len"].fillna(0).astype(int) >= cfg["min_protein_length"]) &
                (up["seq_len"].fillna(0).astype(int) <= cfg["max_protein_length"])].copy()
        rows = []
        for _, r in tqdm(up.iterrows(), total=len(up)):
            species = r["species"]; acc = r["accession"]
            fa = fetch_uniprot_fasta(acc)
            lines = [ln.strip() for ln in fa.strip().splitlines() if ln.strip()]
            seq = "".join(ln for ln in lines if not ln.startswith(">"))
            if not seq: continue
            rows.append({
                "species": species, "target_gene_id": acc, "target_protein_id": acc,
                "taxon_id": r.get("taxon_id"), "seq": seq, "seq_len": len(seq),
                "perc_identity": 0.0, "lineage": []
            })
        orth_rows = rows

    if not orth_rows:
        print("ERROR: No ortholog sequences fetched.", file=sys.stderr); sys.exit(1)

    df = pd.DataFrame(orth_rows).drop_duplicates(subset=["species"])
    df["perc_identity"] = df["perc_identity"].fillna(0.0)
    df = df.sort_values(["perc_identity","seq_len"], ascending=[False, False])

    total_needed = cfg.get("total_species", 50) - 1
    df["label"] = [label_by_policy(r["species"], r.get("lineage", []), policy) for _, r in df.iterrows()]
    df["is_mammal"] = df["label"].eq("close")

    mammals = df[df["is_mammal"]]
    non_mammals = df[~df["is_mammal"]]
    pick = pd.concat([
        mammals.head(cfg.get("min_mammals", 20)),
        non_mammals.head(cfg.get("min_non_mammals", 15))
    ])
    if len(pick) < total_needed:
        remain = df[~df.index.isin(pick.index)]
        pick = pd.concat([pick, remain.head(total_needed - len(pick))])
    pick = pick.head(total_needed).copy()

    combined = [Path(args.human_out).read_text()]
    meta_rows = []
    for _, r in tqdm(pick.iterrows(), total=len(pick)):
        hdr = f">{sanitize(r['species']).replace(' ','_')}|{r['target_protein_id']}|{r['target_gene_id']}|taxon:{r.get('taxon_id')}"
        body = "\n".join([r["seq"][i:i+60] for i in range(0, len(r["seq"]), 60)])
        fa = hdr + "\n" + body + "\n"
        out_fa = Path(args.orthologs_dir) / (sanitize(r["species"]).replace(" ","_") + ".fasta")
        out_fa.write_text(fa)
        combined.append(fa)
        meta_rows.append({
            "species": r["species"],
            "protein_id": r["target_protein_id"],
            "gene_id": r["target_gene_id"],
            "taxon_id": r.get("taxon_id"),
            "perc_identity": r.get("perc_identity", 0.0),
            "seq_len": r["seq_len"],
            "label": r["label"],
            "source": used_source
        })

    Path(args.all_fasta).write_text("".join(combined))
    pd.DataFrame(meta_rows).to_csv(args.species_meta, index=False)

    print("DONE")
    print(f" - Combined FASTA : {args.all_fasta}")
    print(f" - Species meta   : {args.species_meta}")
    print(f" - Ortholog FASTA : data/orthologs/*.fasta")
    print(f" - Source used    : {used_source}")

if __name__ == "__main__":
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    main()
