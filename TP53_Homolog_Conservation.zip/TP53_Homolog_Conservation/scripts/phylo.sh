#!/usr/bin/env bash
set -euo pipefail
mkdir -p results figures logs
if command -v fasttree >/dev/null 2>&1; then
  fasttree -wag results/tp53_50_aln.fasta > results/tp53_tree.nwk 2>logs/fasttree.log
else
  FastTree -wag results/tp53_50_aln.fasta > results/tp53_tree.nwk 2>logs/fasttree.log
fi
echo "Tree: results/tp53_tree.nwk"
